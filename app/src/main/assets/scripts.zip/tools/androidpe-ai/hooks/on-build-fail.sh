#!/usr/bin/env bash
BUILD_LOG="$1"
echo "[AndroidPE-AI-HOOK] Build failed → Running Doctor..."
bash "$HOME/.androidpe/tools/androidpe-ai/bin/androidpe-ai" --log "$BUILD_LOG"
bash "$HOME/.androidpe/tools/androidpe-ai/doctor/sdk-suggest.sh"
bash "$HOME/.androidpe/tools/androidpe-ai/doctor/dependency-fix.sh"
bash "$HOME/.androidpe/tools/androidpe-ai/doctor/manifest-auto-gen.sh"
bash "$HOME/.androidpe/tools/androidpe-ai/doctor/agp-aligner.sh"
